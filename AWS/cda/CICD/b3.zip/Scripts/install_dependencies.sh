sudo su
yum -y update
yum -y install httpd.x86_64
systemctl enable httpd.service 
