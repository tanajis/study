sudo su
systemctl stop httpd.service 
