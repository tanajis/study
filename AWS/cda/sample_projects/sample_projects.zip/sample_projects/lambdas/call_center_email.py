import sys
import smtplib
import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
from email.message import EmailMessage

def lambda_handler(event,context):
    
    try:
        
        name = "Sumit"
        from_address = "tanajisutar415@gmail.com"
        to_address = "tanajisutar415@gmail.com"
        subject = "New Tickes Assigned"
        domain='email-smtp.us-east-1.amazonaws.com'
        username="AKIAVTWXEAGRV7QJ27ME"
        password="BOYTL/qC08YA9FwAVHFaDPLpVbOW3tH9+m6UjC0EJptV"
        port=587
        
        print('check 1')
        
        #read data first
        
        #read all the data that is in status assigned
        dynamodb=boto3.resource('dynamodb')
        table = dynamodb.Table('call_center_executives')
        response = table.scan(
        FilterExpression=Attr('NAME').ne(None))
        call_center_executives=response['Items']
    
        print('check 2')
        for excvs in call_center_executives:
            
            name =excvs['NAME']
            EXID =excvs['EXID']
        
            #get ENQS assigned to him/her
            table = dynamodb.Table('datapoints_assigned')
            response = table.scan(
            FilterExpression=Attr('EXID').eq(EXID))
            datapoints_assigned=response['Items']
        
            print('hellooo',datapoints_assigned)
            body='\nENQNO\tASSIGNED_DATE\n'
            for enq in datapoints_assigned:
                ENQNO=enq['ENQNO']
                ASSIGN_DATE=enq['ASSIGN_DATE']
                body=body+'\n'+str(ENQNO)+'\t'+str(ASSIGN_DATE)
        
    
        
            print('check 3')
            
            body2 = """
            Hello, {0}.
            
            Below ENQNO are assigned to you!!.
                    \t{1}
            
            Kind Regards,
            Me
            """.format(name,body)
            
            #print('check 4',body2)
            
            msg = EmailMessage()
            msg.set_content(body2)
            msg['Subject'] = subject
            msg['From'] = from_address
            msg['To'] = to_address
            
            
            
            server = smtplib.SMTP(domain, port)
            server.starttls()
            server.login(username,password )
            server.sendmail(from_address, to_address, str(msg) )
            server.quit()
    except Exception as e:
        print ("Error: ", e)
    else:
        print ("Email sent!")
