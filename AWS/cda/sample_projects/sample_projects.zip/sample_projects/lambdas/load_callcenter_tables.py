import json
import boto3



def readS3Data(bucket,key):
    try:
        
        s3=boto3.resource('s3')
        data=s3.Object(bucket,key).get()['Body'].read().decode('utf-8').splitlines()
        
        return data
    except Exception as e:
        print('Error while reading from S3:',str(e))
        raise Exception(str(e))


def write2Dynamo(table_name,input_data):
    
    try:
        data =input_data
        dyn=boto3.resource('dynamodb','us-east-1')
        table =dyn.Table(table_name)
        
        #print(input_data)
        
        
        #col_list=str(col_list).split(',')
        
        #print(col_list)
        
        #read config file
        f=open('config.json','r')
        dtypes = json.load(f)[table_name]
        col_list=[keys for keys in dtypes.keys()]
        print(col_list)
        item={}
        
        for row in input_data[1:]:
            print('row',row)
            row=str(row).split(',')
            
            #Add each column
            for ind in range(len(col_list)):
                col_name=col_list[ind]
                
                if dtypes[col_name]=='S':
                    val=str(row[ind]).replace("'",'')
                elif dtypes[col_name]=='N':
                    val=int(row[ind])
                elif dtypes[col_name]=='F':  
                    val=row[ind]
                
                item[col_name]=val
            print(item)
            #item['CCID']=int(item['CCID'])
            #item['EXID']=int(item['EXID'])
            
            
            response=table.put_item(Item=item)
            
        return True
        
    except Exception as e:
        print('Error while writing data to dynamodb:',str(e))
        raise Exception(str(e))
    
    

def lambda_handler(event, context):
    
    s3_bucket='callcenter-mgmt'
    # Read data from s3
    
    #s3://callcenter-mgmt/callcenter_executives.csv
    data=readS3Data(s3_bucket,'call_center_executives.csv')
    #write data to Dynamodb
    response=write2Dynamo('call_center_executives',data)
    
    data=readS3Data(s3_bucket,'call_center_master.csv')
    #write data to Dynamodb
    response=write2Dynamo('call_center_master',data)
    
    data=readS3Data(s3_bucket,'input_datapoints.csv')
    #write data to Dynamodb
    response=write2Dynamo('input_datapoints',data)
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
