import json
import boto3
from boto3.dynamodb.conditions import Key, Attr


def lambda_handler(event, context):
    # TODO implement
    dynamodb = boto3.resource('dynamodb')
    sqs = boto3.resource('sqs')

    
     
    #read all the data that is in status assigned
    table = dynamodb.Table('datapoints_assigned')
    response = table.scan(
    FilterExpression=Attr('STATUS').eq('ASSIGNED'))
    datapoints_assigned=response['Items']
    
    #push that data in queue

    queue = sqs.get_queue_by_name(QueueName='callceneter_enq_queue')
    for rec in datapoints_assigned:
        
        data=str(rec['ENQNO'])+','+str(rec['CCID'])+','+str(rec['EXID'])

        # Create a new message
        response = queue.send_message(MessageBody=data)
    
    
    
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
