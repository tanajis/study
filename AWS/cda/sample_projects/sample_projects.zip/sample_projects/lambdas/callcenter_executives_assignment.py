import json
import boto3
import datetime

#https://boto3.amazonaws.com/v1/documentation/api/latest/guide/dynamodb.html

from boto3.dynamodb.conditions import Key, Attr

def readFromDynamo():
    
    dynamodb = boto3.resource('dynamodb')
    
    #read input_datapoints
    table = dynamodb.Table('input_datapoints')
    response = table.scan(
    FilterExpression=Attr('DESC').ne(None))
    input_datapoints = response['Items']
    
    
    #read call_center_master
    table = dynamodb.Table('call_center_master')
    response = table.scan(
    FilterExpression=Attr('PERCENTAGE').ne(0))
    call_center_master = response['Items']
    
    
    
    #read call_center_executives
    table = dynamodb.Table('call_center_executives')
    response = table.scan(
    FilterExpression=Attr('NAME').ne(None))
    call_center_executives = response['Items']
    
    
    
    #Assign Call Center First
    ENQNOLIST=[]
    for row in input_datapoints:
        ENQNOLIST.append(int(row['ENQNO']))
        
    
    tot=len(ENQNOLIST)
    #calculate percentage and assign share
    assignment=[]
    for row in call_center_master:
        temp={}
        share=int ( tot* int(row['PERCENTAGE']) /100 )
        #print(share)
        
        temp['ENQNOS']=ENQNOLIST[:share]
        temp['CCID']=int(row['CCID'])
        
        #delete them from list
        ENQNOLIST=ENQNOLIST[share:]
        
        assignment.append(temp)
        
    #print('yess',len(assignment))
    
    #update input_datapoints json with call center IDS
    
    datapoints_assigned=[]
    for i in assignment:
        ccid=int(i['CCID'])
        temp={}
        for ENQ in i['ENQNOS']:
            temp['ENQNOS']=int(ENQ)
            temp['CCID']=ccid
            
            datapoints_assigned.append(temp)
        
        
    #print(datapoints_assigned)
        
    datapoints_assigned_exec=[]
    
    #Now assign Executives using roundrobbin
    for i in assignment:
        
        #get list of executives present in that call center
        table = dynamodb.Table('call_center_executives')
        response = table.scan(
        FilterExpression=Attr('CCID').eq(i['CCID']))
        
        exec_for_this_callcenter=response['Items']
        
        exec_list=[int(i['EXID']) for i in exec_for_this_callcenter]
        print('hii',exec_list)
        excnt=len(exec_list)
        dpcnt=len(i['ENQNOS'])
        
        print(excnt,dpcnt)
        k=0
        
        for enq in i['ENQNOS']:
            temp={}
            temp['EXID']=exec_list[int(k%excnt)]
            temp['ENQNO']=enq
            temp['CCID']=i['CCID']
            temp['ASSIGN_DATE']=datetime.datetime.now().strftime("%d-%m-%Y")
            temp['LAST_UPDATE_DATE']=datetime.datetime.now().strftime("%d-%m-%Y")
            temp['STATUS']='ASSIGNED'
            datapoints_assigned_exec.append(temp)
            k=k+1
        
    
    #print('final output',len(datapoints_assigned_exec))
    
    #insert the output the datapoints_assigned
    dyn=boto3.resource('dynamodb','us-east-1')
    table =dyn.Table('datapoints_assigned')
    for rec in datapoints_assigned_exec:
        #print(i)
        response=table.put_item(Item=rec)


def lambda_handler(event, context):
    # TODO implement
    
    readFromDynamo()
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
